package com.intanzaki.transactionprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
