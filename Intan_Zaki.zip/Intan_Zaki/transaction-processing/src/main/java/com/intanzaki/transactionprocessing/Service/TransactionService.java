package com.intanzaki.transactionprocessing.Service;

import com.intanzaki.transactionprocessing.Model.Transaction;
import com.intanzaki.transactionprocessing.Repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    //CREATE RECORD
    public Transaction addTransaction (Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    // Service method to retrieve all transactions
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    // Service method to update the description of a transaction
    public Transaction updateTransactionDescription(Long transactionId, String newDescription) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found with ID: " + transactionId));

        transaction.setDescription(newDescription);
        return transactionRepository.save(transaction);
    }

    // Service method to search transactions by customer ID
    public List<Transaction> getTransactionsByCustomerId(int customerId) {
        return transactionRepository.findByCustomerId(customerId);
    }


    // Service method to search transactions by account number
    public List<Transaction> getTransactionsByAccountNumber(String accountNumber) {
        return transactionRepository.findByAccountNumber(accountNumber);
    }

    // Service method to search transactions by description
    public List<Transaction> getTransactionsByDescription(String description) {
        return transactionRepository.findByDescriptionContaining(description);
    }

    // Service method to handle concurrent update of a transaction
    public Transaction updateTransactionConcurrently(Long transactionId, String newDescription, String expectedDescription) {
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found with ID: " + transactionId));

        if (!transaction.getDescription().equals(expectedDescription)) {
            throw new IllegalStateException("Concurrent update detected. Please try again.");
        }

        transaction.setDescription(newDescription);
        return transactionRepository.save(transaction);
    }


}
