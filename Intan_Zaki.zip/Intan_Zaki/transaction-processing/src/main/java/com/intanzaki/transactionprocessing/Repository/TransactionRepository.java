package com.intanzaki.transactionprocessing.Repository;

import com.intanzaki.transactionprocessing.Model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // Custom query method to find transactions by account number
    List<Transaction> findByAccountNumber(String accountNumber);

    // Find transactions by customer ID
    List<Transaction> findByCustomerId(int customerId);

    // Find transactions by description containing a specific keyword
    List<Transaction> findByDescriptionContaining(String keyword);

    // Find transactions by date between two dates
    List<Transaction> findByDateBetween(LocalDate startDate, LocalDate endDate);

    // Find transactions by amount greater than a specified value
    List<Transaction> findByTrxAmountGreaterThan(BigDecimal amount);

    // Find transactions by account number and description
    List<Transaction> findByAccountNumberAndDescription(String accountNumber, String description);

}
