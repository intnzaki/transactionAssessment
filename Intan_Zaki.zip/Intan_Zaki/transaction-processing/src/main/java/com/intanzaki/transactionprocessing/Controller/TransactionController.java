package com.intanzaki.transactionprocessing.Controller;

import com.intanzaki.transactionprocessing.Model.Transaction;
import com.intanzaki.transactionprocessing.Service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    //http://localhost:8088/api/transactions/readall
    //Read
    @GetMapping ("/readall")
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        List<Transaction> transactions = transactionService.getAllTransactions();
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<Transaction> addTransaction(@RequestBody Transaction transaction) {
        Transaction newTransaction = transactionService.addTransaction(transaction);
        return new ResponseEntity<>(newTransaction, HttpStatus.CREATED);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Transaction>> getTransactionsByCustomerId(@PathVariable int customerId) {
        List<Transaction> transactions = transactionService.getTransactionsByCustomerId(customerId);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

    @GetMapping("/account/{accountNumber}")
    public ResponseEntity<List<Transaction>> getTransactionsByAccountNumber(@PathVariable String accountNumber) {
        List<Transaction> transactions = transactionService.getTransactionsByAccountNumber(accountNumber);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

    //localhost:8088/api/transactions/1/update-description?newDescription=New%20data

        @PutMapping("/{id}/update-description")
        public ResponseEntity<Transaction> updateTransactionDescription(
            @PathVariable Long id,
            @RequestParam String newDescription
        ) {
        Transaction updatedTransaction = transactionService.updateTransactionDescription(id, newDescription);
        return new ResponseEntity<>(updatedTransaction, HttpStatus.OK);
    }


    //http://localhost:8088/api/transactions/search?customerId=222
    @GetMapping("/search")
    public ResponseEntity<List<Transaction>> searchTransactions(
            @RequestParam(required = false) Integer customerId,
            @RequestParam(required = false) String accountNumber,
            @RequestParam(required = false) String description
    ) {
        if (customerId != null) {
            List<Transaction> transactions = transactionService.getTransactionsByCustomerId(customerId);
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        }

        if (accountNumber != null) {
            List<Transaction> transactions = transactionService.getTransactionsByAccountNumber(accountNumber);
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        }

        if (description != null) {
            List<Transaction> transactions = transactionService.getTransactionsByDescription(description);
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }



//    @PutMapping("/{id}")
//    public ResponseEntity<Transaction> updateTransaction(@PathVariable Long id, @RequestBody Transaction updatedTransaction) {
//        Transaction updated = transactionService.updateTransaction(id, updatedTransaction);
//        return new ResponseEntity<>(updated, HttpStatus.OK);
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteTransaction(@PathVariable Long id) {
//        transactionService.deleteTransaction(id);
//        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//    }

}
