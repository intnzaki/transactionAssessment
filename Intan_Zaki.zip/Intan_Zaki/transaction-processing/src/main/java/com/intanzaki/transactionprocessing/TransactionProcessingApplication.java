package com.intanzaki.transactionprocessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//	The main Spring Boot application class
// 	that starts the Spring Boot application.

@SpringBootApplication
public class TransactionProcessingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionProcessingApplication.class, args);
	}

}
